import { useState, useEffect } from "react";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import { queuesAPI, tokensAPI } from "../../services/api";

const STATUS_META = {
  waiting:     { label: "Waiting",     color: "text-amber-600 bg-amber-50 border-amber-200" },
  called:      { label: "Your turn",   color: "text-emerald-600 bg-emerald-50 border-emerald-200" },
  in_progress: { label: "In progress", color: "text-indigo-600 bg-indigo-50 border-indigo-200" },
  completed:   { label: "Completed",   color: "text-slate-500 bg-slate-50 border-slate-200" },
  cancelled:   { label: "Cancelled",   color: "text-red-500 bg-red-50 border-red-200" },
  no_show:     { label: "No show",     color: "text-red-500 bg-red-50 border-red-200" },
};
const ACTIVE_STATUSES = ["waiting", "called", "in_progress"];

export default function QueuePage() {
  const routerLocation = useLocation();
  const navigate = useNavigate();
  const { service_id } = useParams();

 
  const passedService  = routerLocation.state?.service;
  const passedLocation = routerLocation.state?.location;

  const isServiceMode = Boolean(service_id);

  const [queues, setQueues]   = useState([]); // service mode
  const [tokens, setTokens]   = useState([]); // my-queues mode
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState("");

  const [joinedTokens, setJoinedTokens] = useState({}); // { [queue_id]: {tokenNumber, position, estimatedWait} }
  const [joiningId, setJoiningId]       = useState(null);
  const [joinError, setJoinError]       = useState("");

  useEffect(() => {
    if (isServiceMode) loadServiceQueues();
    else loadMyTokens();
  }, [service_id]);

  async function loadServiceQueues() {
    try {
      setLoading(true);
      setError("");
      const res = await queuesAPI.getByService(service_id);
      setQueues(res.data.data || []);
    } catch (err) {
      setError("Failed to load queues for this service.");
    } finally {
      setLoading(false);
    }
  }

  async function loadMyTokens() {
    try {
      setLoading(true);
      setError("");
      const res = await tokensAPI.getMyTokens();
      setTokens(res.data.data || []);
    } catch (err) {
      setError("Failed to load your queues.");
    } finally {
      setLoading(false);
    }
  }

  async function handleJoin(queue) {
    setJoinError("");
    setJoiningId(queue.queue_id);
    try {
      const res = await queuesAPI.join(queue.queue_id, {});
      setJoinedTokens((prev) => ({
        ...prev,
        [queue.queue_id]: {
          tokenNumber:   res.data.tokenNumber   ?? res.data.token?.tokenNumber,
          position:      res.data.position      ?? null,
          estimatedWait: res.data.estimatedWait ?? null,
        },
      }));
    } catch (err) {
      setJoinError(err.response?.data?.message || "Failed to join queue. Try again.");
    } finally {
      setJoiningId(null);
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center py-24">
        <div className="w-8 h-8 border-2 border-[#727EFD] border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6 max-w-3xl mx-auto">
        <p className="text-red-500 font-medium">{error}</p>
      </div>
    );
  }

  // ───────── SERVICE MODE--------------------------
  if (isServiceMode) {
    return (
      <div className="p-6 max-w-3xl mx-auto space-y-6">
        <button onClick={() => navigate(-1)} className="text-sm font-semibold text-[#727EFD] hover:underline">
          ← Back to services
        </button>

        <div className="flex items-center gap-4">
          <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl
            bg-gradient-to-br from-[#727EFD] to-[#9b87f5] shadow-md shadow-indigo-200">
            🎫
          </div>
          <div>
            <h1 className="text-2xl font-bold text-slate-800">
              {passedService?.service_name || "Service Queue"}
            </h1>
            {passedLocation && (
              <p className="text-sm text-slate-500">{passedLocation.name} · {passedLocation.city}</p>
            )}
          </div>
        </div>

        {joinError && (
          <div className="bg-red-50 border border-red-200 text-red-600 rounded-xl px-4 py-3 text-sm">
            {joinError}
          </div>
        )}

        {queues.length === 0 ? (
          <div className="bg-white rounded-2xl border border-slate-100 shadow-sm flex flex-col
            items-center justify-center py-20 text-slate-400">
            <div className="text-4xl mb-3">🎫</div>
            <p className="font-semibold text-slate-500">No open queues for this service right now</p>
          </div>
        ) : (
          <div className="space-y-4">
            {queues.map((queue) => {
              const joined = joinedTokens[queue.queue_id];
              return (
                <div key={queue.queue_id} className="bg-white rounded-2xl border border-slate-100 shadow-sm p-5 flex items-center justify-between gap-4">
                  <div>
                    <p className="font-bold text-slate-800">{queue.queue_name || `Queue #${queue.queue_id}`}</p>
                    <p className="text-sm text-slate-500 mt-1">
                      {queue.waiting_count ?? 0} waiting
                      {queue.estimated_wait ? ` · ~${queue.estimated_wait} min` : ""}
                    </p>
                  </div>

                  {joined ? (
                    <div className="text-right">
                      <p className="text-xs font-semibold text-emerald-600">✓ Joined</p>
                      <p className="text-lg font-bold text-[#727EFD]">#{joined.tokenNumber}</p>
                    </div>
                  ) : (
                    <button
                      onClick={() => handleJoin(queue)}
                      disabled={joiningId === queue.queue_id}
                      className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-[#727EFD] to-[#9b87f5] text-white font-bold text-sm shadow-md shadow-indigo-200 hover:opacity-90 disabled:opacity-60 transition-opacity"
                    >
                      {joiningId === queue.queue_id ? "Joining…" : "Join Queue"}
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </div>
    );
  }

  // ───────── MY QUEUES MODE: 
  const active  = tokens.filter((t) => ACTIVE_STATUSES.includes(t.status));
  const history = tokens.filter((t) => !ACTIVE_STATUSES.includes(t.status));

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-8">
      <div>
        <h1 className="text-2xl font-bold text-slate-800">My Queues</h1>
        <p className="text-sm text-slate-500">Your active tokens and queue history</p>
      </div>

      <section className="space-y-3">
        <h2 className="text-sm font-semibold text-slate-500 uppercase tracking-wide">Active</h2>
        {active.length === 0 ? (
          <p className="text-sm text-slate-400">You're not in any queue right now.</p>
        ) : active.map((t) => <TokenRow key={t.token_id} token={t} />)}
      </section>

      <section className="space-y-3">
        <h2 className="text-sm font-semibold text-slate-500 uppercase tracking-wide">History</h2>
        {history.length === 0 ? (
          <p className="text-sm text-slate-400">No past queues yet.</p>
        ) : history.map((t) => <TokenRow key={t.token_id} token={t} />)}
      </section>
    </div>
  );
}

function TokenRow({ token }) {
  const meta = STATUS_META[token.status] ?? STATUS_META.completed;
  return (
    <div className="bg-white rounded-2xl border border-slate-100 shadow-sm p-4 flex items-center justify-between gap-4">
      <div>
        <p className="font-bold text-slate-800">{token.queue_name || token.service_name || `Token #${token.token_number}`}</p>
        <p className="text-sm text-slate-500 mt-0.5">Token #{token.token_number}</p>
      </div>
      <span className={`text-xs font-semibold px-3 py-1 rounded-full border ${meta.color}`}>{meta.label}</span>
    </div>
  );
}